package application;

import java.lang.String;
//import java.lang.Math;
	
import javafx.application.Application;
import javafx.application.Platform;

import javafx.stage.Stage;
import javafx.scene.Scene;
//import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
/*
import javafx.scene.*;
import javafx.scene.paint.*;
import javafx.scene.shape.*;
*/

import javafx.event.ActionEvent;
import javafx.event.EventHandler;

import javafx.scene.control.Button;
//import javafx.scene.control.Label;
//import javafx.scene.layout.VBox;
//import javafx.scene.layout.HBox;
import javafx.scene.control.TextArea;
//import javafx.scene.control.TextField;
import javafx.scene.paint.Color;



public class Calcolatore extends Application{
	
	
	//introducing the keys;
		Button button0;
		Button button1;
		Button button2;
		Button button3;
		Button button4;
		Button button5;
		Button button6;
		Button button7;
		Button button8;
		Button button9;
		Button buttonPi;
		Button buttonNepero;
		Button buttonplus;
		Button buttonminus;
		Button buttontimes;
		Button buttondivide;
		Button buttonequal;
		Button buttonC;
		Button buttondot;
		Button buttonBack;
	
	//textArea:
	public static TextArea textArea = new TextArea();
	
	//textArea.setPrefColumnCount(1);
	
	//printing on scene method
	public static void println(String s){
		    Platform.runLater(new Runnable() {
		    	//in case you call from other thread
		        @Override
		        public void run() {
		            textArea.setText(textArea.getText()+s);
		            //System.out.println(s);
		            //for echo if you want
		        }
		    });
	}
	
	
	@Override
	public void start(Stage stage) throws Exception{
		    
		//BorderPane root = new BorderPane();
		//VBox root = new VBox();
		GridPane root = new GridPane();
		
		//Group root = new Group();
		
		Scene scene = new Scene(root,250,300, Color.BLACK);
		scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
		stage.setScene(scene);
		
		
		stage.setTitle("Calcolatrice");
		
		
		Buttoning();
		
		
		//root.getChildren().add(textArea);
		root.add(textArea, 0, 0, 5, 1);

		//root.getChildren().add(button0);
		root.add(button0, 0, 5);
		root.add(buttonNepero, 0, 3);
		root.add(buttonPi, 0, 4);
		root.add(buttondot, 1, 2);
		
		root.add(button7, 1, 3);
		root.add(button4, 1, 4);
		root.add(button1, 1, 5);
		
		root.add(button8, 2, 3);
		root.add(button5, 2, 4);
		root.add(button2, 2, 5);
		
		root.add(button9, 3, 3);
		root.add(button6, 3, 4);
		root.add(button3, 3, 5);
		
		root.add(buttonplus, 4, 4);
		root.add(buttonminus, 4, 3);
		root.add(buttontimes, 3, 2);
		root.add(buttondivide, 2, 2);
		
		root.add(buttonequal, 4, 5);
		root.add(buttonC, 4, 2);
		root.add(buttonBack, 0, 2);

		stage.show();
		
	}
	
	//integer
		int finish = 0;
		int countingDots = 0;
	//doubles
		Double a;
		Double b;
	//char
		char operation;
		
	
	//actual math
	public void Operations() {
		
		finish = 1;
		
		switch(operation) {
			
			case '+' :
				b = Double.parseDouble(textArea.getText());
				String s1 = String.valueOf(a+b);
				textArea.setText(s1);
				break;
			case '-' :
				b = Double.parseDouble(textArea.getText());
				String s2 = String.valueOf(a-b);
				textArea.setText(s2);
				break;
			case 'x' :
				b = Double.parseDouble(textArea.getText());
				String s3 = String.valueOf(a*b);
				textArea.setText(s3);
				break;
			case ':' :
				b = Double.parseDouble(textArea.getText());
				if(b==0 || b==0.0) {
					textArea.setText("MATH ERROR");
					finish = 1;
					break;
				}
				String s4 = String.valueOf(a/b);
				textArea.setText(s4);
				break;
			default :
				textArea.setText("ERROR");
				finish = 1;
		}
		
	}
	
	
	public void Buttoning(){

		
		//instances and style	
		button0 = new Button("0");
		button0.setMinSize(50,50);
		button0.setStyle("-fx-background-color: #000000; -fx-font-size: 2em;");
		button0.setTextFill(Color.GREEN); 
		
		button1 = new Button("1");
		button1.setMinSize(50,50);
		button1.setStyle("-fx-background-color: #000000; -fx-font-size: 2em;");
		button1.setTextFill(Color.GREEN); 
		
		button2 = new Button("2");
		button2.setMinSize(50,50);
		button2.setStyle("-fx-background-color: #000000; -fx-font-size: 2em;");
		button2.setTextFill(Color.GREEN);
		
		button3 = new Button("3");
		button3.setMinSize(50,50);
		button3.setStyle("-fx-background-color: #000000; -fx-font-size: 2em;");
		button3.setTextFill(Color.GREEN);
		
		button4 = new Button("4");
		button4.setMinSize(50,50);
		button4.setStyle("-fx-background-color: #000000; -fx-font-size: 2em;");
		button4.setTextFill(Color.GREEN);
		
		button5 = new Button("5");
		button5.setMinSize(50,50);
		button5.setStyle("-fx-background-color: #000000; -fx-font-size: 2em;");
		button5.setTextFill(Color.GREEN);
		
		button6 = new Button("6");
		button6.setMinSize(50,50);
		button6.setStyle("-fx-background-color: #000000; -fx-font-size: 2em;");
		button6.setTextFill(Color.GREEN);
		
		button7 = new Button("7");
		button7.setMinSize(50,50);
		button7.setStyle("-fx-background-color: #000000; -fx-font-size: 2em;");
		button7.setTextFill(Color.GREEN);
		
		button8 = new Button("8");
		button8.setMinSize(50,50);
		button8.setStyle("-fx-background-color: #000000; -fx-font-size: 2em;");
		button8.setTextFill(Color.GREEN);
		
		button9 = new Button("9");
		button9.setMinSize(50,50);
		button9.setStyle("-fx-background-color: #000000; -fx-font-size: 2em;");
		button9.setTextFill(Color.GREEN);
		
		buttonPi = new Button("pi");
		buttonPi.setMinSize(50,50);
		buttonPi.setStyle("-fx-background-color: #000000; -fx-font-size: 2em;");
		buttonPi.setTextFill(Color.GREEN);
		
		buttonNepero = new Button("e");
		buttonNepero.setMinSize(50,50);
		buttonNepero.setStyle("-fx-background-color: #000000; -fx-font-size: 2em;");
		buttonNepero.setTextFill(Color.GREEN); 
		
		buttonplus = new Button("+");
		buttonplus.setMinSize(50,50);
		buttonplus.setStyle("-fx-background-color: #00ff00; -fx-font-size: 2em;");
		buttonplus.setTextFill(Color.BLACK);
		
		buttonminus = new Button("-");
		buttonminus.setMinSize(50,50);
		buttonminus.setStyle("-fx-background-color: #00ff00; -fx-font-size: 3em;");
		buttonminus.setTextFill(Color.BLACK);
		
		buttontimes = new Button("x");
		buttontimes.setMinSize(50,50);
		buttontimes.setStyle("-fx-background-color: #00ff00; -fx-font-size: 2em;");
		buttontimes.setTextFill(Color.BLACK);
		
		buttondivide = new Button(":");
		buttondivide.setMinSize(50,50);
		buttondivide.setStyle("-fx-background-color: #00ff00; -fx-font-size: 2em;");
		buttondivide.setTextFill(Color.BLACK);
		
		buttonequal = new Button("=");
		buttonequal.setMinSize(50,50);
		buttonequal.setStyle("-fx-background-color: #00ff00; -fx-font-size: 2em;");
		buttonequal.setTextFill(Color.BLACK);
		
		buttonC = new Button("C");
		buttonC.setMinSize(50,50);
		buttonC.setStyle("-fx-background-color: #000000; -fx-font-size: 2em;");
		buttonC.setTextFill(Color.RED);
		
		buttondot = new Button(".");
		buttondot.setMinSize(50,50);
		buttondot.setStyle("-fx-background-color: #000000; -fx-font-size: 2em;");
		buttondot.setTextFill(Color.GREEN);
		
		buttonBack = new Button("<-");
		buttonBack.setMinSize(50,50);
		buttonBack.setStyle("-fx-background-color: #000000; -fx-font-size: 2em;");
		buttonBack.setTextFill(Color.BLUE);
		
		
		//actual button action
		button0.setOnAction(new EventHandler<ActionEvent>() {
			
			public void handle(ActionEvent event) {
				if(finish==1) {
					finish = 0;
					textArea.setText("");
					countingDots = 0;
				}
				Calcolatore.println("0");				
			}
		});

		button1.setOnAction(new EventHandler<ActionEvent>() {
			
			public void handle(ActionEvent event) {
				if(finish==1) {
					finish = 0;
					textArea.setText("");
					countingDots = 0;
				}
				Calcolatore.println("1");				
			}
		});
		
		button2.setOnAction(new EventHandler<ActionEvent>() {
			
			public void handle(ActionEvent event) {
				if(finish==1) {
					finish = 0;
					textArea.setText("");	
					countingDots = 0;
				}
				Calcolatore.println("2");				
			}
		});
		
		button3.setOnAction(new EventHandler<ActionEvent>() {
	
			public void handle(ActionEvent event) {
				if(finish==1) {
					finish = 0;
					textArea.setText("");
					countingDots = 0;
				}
				Calcolatore.println("3");				
			}
		});
		
		button4.setOnAction(new EventHandler<ActionEvent>() {
			
			public void handle(ActionEvent event) {
				if(finish==1) {
					finish = 0;
					textArea.setText("");
					countingDots = 0;
				}
				Calcolatore.println("4");				
			}
		});
		
		button5.setOnAction(new EventHandler<ActionEvent>() {
			
			public void handle(ActionEvent event) {
				if(finish==1) {
					finish = 0;
					textArea.setText("");
					countingDots = 0;
				}
				Calcolatore.println("5");				
			}
		});
		
		button6.setOnAction(new EventHandler<ActionEvent>() {
			
			public void handle(ActionEvent event) {
				if(finish==1) {
					finish = 0;
					textArea.setText("");
					countingDots = 0;
				}
				Calcolatore.println("6");				
			}
		});
		
		button7.setOnAction(new EventHandler<ActionEvent>() {
			
			public void handle(ActionEvent event) {
				if(finish==1) {
					finish = 0;
					textArea.setText("");
					countingDots = 0;
				}
				Calcolatore.println("7");				
			}
		});

		button8.setOnAction(new EventHandler<ActionEvent>() {
	
			public void handle(ActionEvent event) {
				if(finish==1) {
					finish = 0;
					textArea.setText("");
					countingDots = 0;
				}
				Calcolatore.println("8");				
			}
		});

		button9.setOnAction(new EventHandler<ActionEvent>() {
	
			public void handle(ActionEvent event) {
				if(finish==1) {
					finish = 0;
					textArea.setText("");
					countingDots = 0;
				}
				Calcolatore.println("9");				
			}
		});
		
		buttonPi.setOnAction(new EventHandler<ActionEvent>() {
			
			public void handle(ActionEvent event) {
				if(finish==1) {
					finish = 0;
					textArea.setText("");
					countingDots = 0;
				}
				Calcolatore.println("3.1415926535897");				
			}
		});
		
		buttonNepero.setOnAction(new EventHandler<ActionEvent>() {
			
			public void handle(ActionEvent event) {
				if(finish==1) {
					finish = 0;
					textArea.setText("");
					countingDots = 0;
				}
				Calcolatore.println("2.7182818284590");				
			}
		});

		buttondot.setOnAction(new EventHandler<ActionEvent>() {
			
			public void handle(ActionEvent event) {
				if(finish==1) {
					finish = 0;
					textArea.setText("");	
				}
				Calcolatore.println(".");
				countingDots += 1;
			}
		});
		
		//operating buttons
		
		buttonplus.setOnAction(new EventHandler<ActionEvent>() {
			
			public void handle(ActionEvent event) {
				
				if(finish == 0 && countingDots < 2) {
					if((textArea.getText()!="") && ((textArea.getText()).equals(".")==false)) {
						finish = 1;
						a = Double.parseDouble(textArea.getText());
						textArea.setText("");				
						operation = '+';
					}
				}
				else {
					textArea.setText("ERROR");
					countingDots = 0;
				}
			 	
			}
		});
		

		buttonminus.setOnAction(new EventHandler<ActionEvent>() {
	
			public void handle(ActionEvent event) {
				
				if(finish == 0 && countingDots < 2) {
					if(textArea.getText()!="" && ((textArea.getText()).equals(".")==false)) {
						finish = 1;
						a = Double.parseDouble(textArea.getText());
						textArea.setText("");				
						operation = '-';
					}
				}
				else {
					textArea.setText("ERROR");
					countingDots = 0;
				}
			 				
			}
		});
		
		buttontimes.setOnAction(new EventHandler<ActionEvent>() {
			
			public void handle(ActionEvent event) {
				
				if(finish == 0 && countingDots < 2) {
					if(textArea.getText()!="" && ((textArea.getText()).equals(".")==false)) {
						finish = 1;
						a = Double.parseDouble(textArea.getText());
						textArea.setText("");				
						operation = 'x';
					}
				}
				else {
					textArea.setText("ERROR");
					countingDots = 0;
				}
			}
		});
		
		buttondivide.setOnAction(new EventHandler<ActionEvent>() {
			
			public void handle(ActionEvent event) {
				
				if(finish == 0 && countingDots < 2) {
					if(textArea.getText()!="" && ((textArea.getText()).equals(".")==false)) {
						finish = 1;
						a = Double.parseDouble(textArea.getText());
						textArea.setText("");				
						operation = ':';
					}
				}
				else {
					textArea.setText("ERROR");
					countingDots = 0;
				}
			 					
			}
		});
		
		buttonequal.setOnAction(new EventHandler<ActionEvent>() {
			
			public void handle(ActionEvent event) {
				
				if(countingDots < 2) {
				
					if(finish==0) {
						Operations();
					}
					else {
						textArea.setText("ERROR");
						finish = 1;
					}
				}
				else {
					textArea.setText("ERROR");
					finish = 1;
				}
				
			}
		});
		
		
		buttonC.setOnAction(new EventHandler<ActionEvent>() {
			
			public void handle(ActionEvent event) {
				
				countingDots = 0;
				textArea.setText("");	
				
			}
		});
		
		buttonBack.setOnAction(new EventHandler<ActionEvent>() {
				public void handle(ActionEvent event) {
						String str = textArea.getText();
						if(str!="") {
							int Len = (textArea.getText()).length();
							String New = str.substring(0, Len-1);
							textArea.setText(New);
							
							//check to see if I deleted dots
							String checkingDots = str.substring(Len-1, Len);
							if(checkingDots == ".") {
								countingDots -= 1;
							}
							
							if(((textArea.getText()).equals("ERROR")==false) || ((textArea.getText()).equals("MATH ERROR")==false)) {
								countingDots = 0;
								textArea.setText("");
							}
						}
						
				}
		});
		
	}
	
	
	
	public static void main(String[] args) {
		launch(args);
	}
}
